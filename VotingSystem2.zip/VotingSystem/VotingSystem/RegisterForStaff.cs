﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace VotingSystem
{
    public partial class RegisterForStaff : Form
    {
        public RegisterForStaff()
        {
            InitializeComponent();
        }

        string strcon, strsql;
        SqlConnection mycon;
        SqlCommand command;
        //Link the database
        private bool DBConnect()
        {


            try
            {
                strcon = "Data Source=DESKTOP-BAERS9T\\SQLEXPRESS;Initial Catalog=Voting;Integrated Security=True";
                mycon = new SqlConnection(strcon);
                mycon.Open();

                MessageBox.Show("Link datebase is succesfully");
                return true;
            }
            catch
            {
                MessageBox.Show("Link datebase is not succesfully");
                return false;
            }
            //Check the database
        }

        

        private void RegisterForStaff_Load(object sender, EventArgs e)
        {
            
        }

        private void Home_btn_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.ShowDialog(this);
        }

        private void Exit_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Font_Box_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Font_Box.Text[0].ToString() == "1")
            {
                StaffId_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                StaffName_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Role_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);
                OK_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Home_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 10, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 10, FontStyle.Bold);

            }
            if (Font_Box.Text[0].ToString() == "2")
            {
                StaffId_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                StaffName_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Role_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);
                OK_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Home_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 12, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 12, FontStyle.Bold);

            }
            if (Font_Box.Text[0].ToString() == "3")
            {
                StaffId_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                StaffName_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Role_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
                OK_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Home_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 14, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 14, FontStyle.Bold);
            }
            if (Font_Box.Text[0].ToString() == "4")
            {
                StaffId_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Password_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                StaffName_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Role_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
                OK_btn.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Home_btn.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Exit_btn.Font = new Font("Tahoma", 15, FontStyle.Bold);
                Font_lab.Font = new Font("Tahoma", 15, FontStyle.Bold);
            }
        }

        private void OK_btn_Click(object sender, EventArgs e)
        {
            if (DBConnect())
            {
                strsql = string.Format("insert into VotingStaff(StaffId,StaffName,Password,Role) values('{0}','{1}','{2}','{3}')", StaffId_txt.Text, StaffName_txt.Text, Password_txt.Text,  Role_comboBox.Text);
                //Add information in the database
                MessageBox.Show(strsql);
                command = new SqlCommand(strsql, mycon);
                try
                {
                    command.ExecuteScalar();
                    MessageBox.Show("Successfully register.");

                }
                catch
                {
                    MessageBox.Show("Register Error.");
                }
                //Check register
                finally
                {
                    mycon.Close();
                }
                //Close the database
            }
        }
    }
}
