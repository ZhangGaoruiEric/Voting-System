﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VotingSystem
{
    class Time
    {
        public static int i;
        public static int a;
        public static int b;
        public static int c;
    }
}
