﻿namespace VotingSystem
{
    partial class RegisterForStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Home_btn = new System.Windows.Forms.Button();
            this.StaffId_txt = new System.Windows.Forms.TextBox();
            this.StaffId_lab = new System.Windows.Forms.Label();
            this.Exit_btn = new System.Windows.Forms.Button();
            this.OK_btn = new System.Windows.Forms.Button();
            this.Role_lab = new System.Windows.Forms.Label();
            this.Password_txt = new System.Windows.Forms.TextBox();
            this.StaffName_txt = new System.Windows.Forms.TextBox();
            this.Password_lab = new System.Windows.Forms.Label();
            this.StaffName_lab = new System.Windows.Forms.Label();
            this.Role_comboBox = new System.Windows.Forms.ComboBox();
            this.Font_Box = new System.Windows.Forms.ComboBox();
            this.Font_lab = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Home_btn
            // 
            this.Home_btn.Location = new System.Drawing.Point(508, 422);
            this.Home_btn.Name = "Home_btn";
            this.Home_btn.Size = new System.Drawing.Size(93, 44);
            this.Home_btn.TabIndex = 31;
            this.Home_btn.Text = "Home";
            this.Home_btn.UseVisualStyleBackColor = true;
            this.Home_btn.Click += new System.EventHandler(this.Home_btn_Click);
            // 
            // StaffId_txt
            // 
            this.StaffId_txt.Location = new System.Drawing.Point(520, 101);
            this.StaffId_txt.Name = "StaffId_txt";
            this.StaffId_txt.Size = new System.Drawing.Size(145, 25);
            this.StaffId_txt.TabIndex = 30;
            // 
            // StaffId_lab
            // 
            this.StaffId_lab.AutoSize = true;
            this.StaffId_lab.Location = new System.Drawing.Point(383, 101);
            this.StaffId_lab.Name = "StaffId_lab";
            this.StaffId_lab.Size = new System.Drawing.Size(79, 15);
            this.StaffId_lab.TabIndex = 29;
            this.StaffId_lab.Text = "Staff Id:";
            // 
            // Exit_btn
            // 
            this.Exit_btn.Location = new System.Drawing.Point(745, 422);
            this.Exit_btn.Name = "Exit_btn";
            this.Exit_btn.Size = new System.Drawing.Size(111, 44);
            this.Exit_btn.TabIndex = 27;
            this.Exit_btn.Text = "Exit";
            this.Exit_btn.UseVisualStyleBackColor = true;
            this.Exit_btn.Click += new System.EventHandler(this.Exit_btn_Click);
            // 
            // OK_btn
            // 
            this.OK_btn.Location = new System.Drawing.Point(240, 422);
            this.OK_btn.Name = "OK_btn";
            this.OK_btn.Size = new System.Drawing.Size(106, 44);
            this.OK_btn.TabIndex = 26;
            this.OK_btn.Text = "OK";
            this.OK_btn.UseVisualStyleBackColor = true;
            this.OK_btn.Click += new System.EventHandler(this.OK_btn_Click);
            // 
            // Role_lab
            // 
            this.Role_lab.AutoSize = true;
            this.Role_lab.Location = new System.Drawing.Point(380, 321);
            this.Role_lab.Name = "Role_lab";
            this.Role_lab.Size = new System.Drawing.Size(47, 15);
            this.Role_lab.TabIndex = 25;
            this.Role_lab.Text = "Role:";
            // 
            // Password_txt
            // 
            this.Password_txt.Location = new System.Drawing.Point(520, 241);
            this.Password_txt.Name = "Password_txt";
            this.Password_txt.Size = new System.Drawing.Size(145, 25);
            this.Password_txt.TabIndex = 20;
            // 
            // StaffName_txt
            // 
            this.StaffName_txt.Location = new System.Drawing.Point(520, 172);
            this.StaffName_txt.Name = "StaffName_txt";
            this.StaffName_txt.Size = new System.Drawing.Size(145, 25);
            this.StaffName_txt.TabIndex = 19;
            // 
            // Password_lab
            // 
            this.Password_lab.AutoSize = true;
            this.Password_lab.Location = new System.Drawing.Point(380, 241);
            this.Password_lab.Name = "Password_lab";
            this.Password_lab.Size = new System.Drawing.Size(79, 15);
            this.Password_lab.TabIndex = 18;
            this.Password_lab.Text = "Password:";
            // 
            // StaffName_lab
            // 
            this.StaffName_lab.AutoSize = true;
            this.StaffName_lab.Location = new System.Drawing.Point(380, 182);
            this.StaffName_lab.Name = "StaffName_lab";
            this.StaffName_lab.Size = new System.Drawing.Size(87, 15);
            this.StaffName_lab.TabIndex = 17;
            this.StaffName_lab.Text = "StaffName:";
            // 
            // Role_comboBox
            // 
            this.Role_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Role_comboBox.FormattingEnabled = true;
            this.Role_comboBox.Items.AddRange(new object[] {
            "Staff",
            "Super Staff"});
            this.Role_comboBox.Location = new System.Drawing.Point(520, 321);
            this.Role_comboBox.Name = "Role_comboBox";
            this.Role_comboBox.Size = new System.Drawing.Size(145, 23);
            this.Role_comboBox.TabIndex = 84;
            // 
            // Font_Box
            // 
            this.Font_Box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Font_Box.FormattingEnabled = true;
            this.Font_Box.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.Font_Box.Location = new System.Drawing.Point(839, 43);
            this.Font_Box.Name = "Font_Box";
            this.Font_Box.Size = new System.Drawing.Size(121, 23);
            this.Font_Box.TabIndex = 85;
            this.Font_Box.SelectedIndexChanged += new System.EventHandler(this.Font_Box_SelectedIndexChanged);
            // 
            // Font_lab
            // 
            this.Font_lab.AutoSize = true;
            this.Font_lab.Location = new System.Drawing.Point(742, 51);
            this.Font_lab.Name = "Font_lab";
            this.Font_lab.Size = new System.Drawing.Size(47, 15);
            this.Font_lab.TabIndex = 86;
            this.Font_lab.Text = "Font:";
            // 
            // RegisterForStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1033, 540);
            this.Controls.Add(this.Font_lab);
            this.Controls.Add(this.Font_Box);
            this.Controls.Add(this.Role_comboBox);
            this.Controls.Add(this.Home_btn);
            this.Controls.Add(this.StaffId_txt);
            this.Controls.Add(this.StaffId_lab);
            this.Controls.Add(this.Exit_btn);
            this.Controls.Add(this.OK_btn);
            this.Controls.Add(this.Role_lab);
            this.Controls.Add(this.Password_txt);
            this.Controls.Add(this.StaffName_txt);
            this.Controls.Add(this.Password_lab);
            this.Controls.Add(this.StaffName_lab);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "RegisterForStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegisterForStaff";
            this.Load += new System.EventHandler(this.RegisterForStaff_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Home_btn;
        private System.Windows.Forms.TextBox StaffId_txt;
        private System.Windows.Forms.Label StaffId_lab;
        private System.Windows.Forms.Button Exit_btn;
        private System.Windows.Forms.Button OK_btn;
        private System.Windows.Forms.Label Role_lab;
        private System.Windows.Forms.TextBox Password_txt;
        private System.Windows.Forms.TextBox StaffName_txt;
        private System.Windows.Forms.Label Password_lab;
        private System.Windows.Forms.Label StaffName_lab;
        private System.Windows.Forms.ComboBox Role_comboBox;
        private System.Windows.Forms.ComboBox Font_Box;
        private System.Windows.Forms.Label Font_lab;
    }
}